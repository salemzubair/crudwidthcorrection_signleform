import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  newpopup!: FormGroup
  constructor(private route: Router) { }
  headings = [
    "S.no",
    "First name",
    "Last name",
    "Department",
    "Username",
    "Password",
    "Cnf password",
    "Email",
    "Contact",
    "Actions"
  ]
  obj: any[] = []
  ngOnInit(): void {
 
      this.obj = JSON.parse(localStorage.getItem('signup')!)
    
  }

  ondelete(id: number) {
    this.obj.splice(id, 1);
    localStorage.setItem('signup', JSON.stringify(this.obj));
  }


  onedit(id: number) {
    localStorage.setItem('id',JSON.stringify(id))
  }




}




