import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  myform!: FormGroup;
  editid: any;

  ngOnInit(): void {
    this.myform = new FormGroup({
      'Firstname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Lastname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Email': new FormControl(null, [Validators.required, Validators.email]),
      'Contact': new FormControl(null, [Validators.required, Validators.pattern('[0-9]{10}')]),
      'Dept': new FormControl(null, [Validators.required]),
      'Username': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Password': new FormControl(null, [Validators.required,]),
      'Confirmpassword': new FormControl(null, [Validators.required]),
    })

    this.obj = JSON.parse(localStorage.getItem('signup')!);
    this.editid = JSON.parse(localStorage.getItem('id')!);
    if (this.editid != null) {
      this.myform.patchValue(this.obj[this.editid])
    }
  }

  obj: any[] = []
  onsubmit() {
    if (this.editid!=null) {
    if(this.myform.value.Password == this.myform.value.Confirmpassword)
    {
      this.obj[this.editid]=this.myform.value;
      localStorage.setItem('signup', JSON.stringify(this.obj));
      this.myform.reset();
      localStorage.removeItem('id');
    }
    else{
      console.error('Password and Confirmpassword  does not match!!!!!');
    }
    }

    else {
      if (this.myform.value.Password == this.myform.value.Confirmpassword) {
        this.obj.push(this.myform.value);
        localStorage.setItem('signup', JSON.stringify(this.obj));
        this.myform.reset();
      }

      else {
        console.error('Password and Confirmpassword  does not match!!!!!');

      }
    }

  }
}
